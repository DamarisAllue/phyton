# setup.py
from setuptools import setup, find_packages

setup(
    name='mi_paquete',
    version='0.2',  # Incrementa la versión para la segunda entrega
    packages=find_packages(),
    install_requires=[
        # Dependencias si las tienes
    ],
)